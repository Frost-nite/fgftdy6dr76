const DiscordMusicBot = require("./structures/DiscordMusicBot");
const client = new DiscordMusicBot();

client.login(require("./config").Token)

module.exports = client; //;-;
